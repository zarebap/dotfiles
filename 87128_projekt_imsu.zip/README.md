# MultiLearn — VARK Learning Style Assessment

## Czym jest projekt?

**MultiLearn** to aplikacja webowa do oceny indywidualnego stylu uczenia się za pomocą ankiety **VARK** (Visual, Auditory, Reading/Writing, Kinesthetic).

Projektu pozwala użytkownikom:
- Zalogować się lub zarejestrować
- Wypełnić interaktywną ankietę VARK (16 pytań)
- Uzyskać spersonalizowany wynik ich preferowanego stylu uczenia się
- Przechowywanie wyników w bazie danych dla przyszłych analiz
- Możliwość przeglądania kursów dopasowanych do ich stylu uczenia się

### Stack techniczny
- **Frontend**: React 18 + TypeScript + React Router
- **Backend**: Node.js + Express + PostgreSQL
- **Autentykacja**: Session-based (express-session) + JWT
- **Baza danych**: PostgreSQL

---

## Wymagania

### Przed instalacją upewnij się, że masz:
- **Node.js** 16+ (z `npm`)
- **PostgreSQL** 12+ (uruchomiony i dostępny)

---

## Instalacja

### 1. Sklonuj lub skopiuj projekt

```bash
cd /home/arcz/uni/imsu/project
```

### 2. Zainstaluj zależności backendu

```bash
cd backend
npm install
```

### 3. Zainstaluj zależności frontendu

```bash
cd ..
npm install
```

### 4. Skonfiguruj bazę danych

#### Utwórz bazę i użytkownika (w psql)
```sql
CREATE DATABASE multilearn;
CREATE USER multilearn_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE multilearn TO multilearn_user;
```

#### Utwórz tabele
```bash
psql -U multilearn_user -d multilearn -f backend/migrations/init.sql
```

lub ręcznie w psql:
```sql
-- Użytkownik
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  has_completed_survey BOOLEAN DEFAULT FALSE,
  vark_scores JSONB DEFAULT '{}'::jsonb,
  preferred_vark VARCHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pytania ankiety
CREATE TABLE questions (
  id SERIAL PRIMARY KEY,
  text TEXT NOT NULL
);

-- Odpowiedzi
CREATE TABLE answers (
  id SERIAL PRIMARY KEY,
  question_id INTEGER REFERENCES questions(id),
  text TEXT NOT NULL,
  vark_type VARCHAR(20) NOT NULL
);

-- Wyniki ankiety
CREATE TABLE survey_results (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  question_id INTEGER REFERENCES questions(id),
  answer_id INTEGER REFERENCES answers(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sesje
CREATE TABLE "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL,
  PRIMARY KEY ("sid")
);
```

#### Wstaw pytania i odpowiedzi (16 pytań VARK)
Odpowiedzi są dostępne w bazie — użyj SQL insert lub importu.

### 5. Skonfiguruj zmienne środowiskowe

#### Backend (.env)

Utwórz plik `backend/.env`:
```env
DATABASE_URL=postgresql://multilearn_user:your_password@localhost:5432/multilearn
SESSION_SECRET=your_secret_key_here
JWT_SECRET=your_jwt_secret_here
PORT=5000
```

#### Frontend
Frontend odwołuje się do backendu na `http://localhost:5000/api` (zdefiniowane w `src/api/api.ts`).

---

## Uruchomienie

### Terminal 1: Backend
```bash
cd backend
npm start
```
Serwer uruchomi się na **http://localhost:5000**

Powinieneś zobaczyć:
```
Server running on port 5000
```

### Terminal 2: Frontend
```bash
npm run dev
```
Aplikacja uruchomi się na **http://localhost:5173**

Otwórz w przeglądarce: **http://localhost:5173**

---

## Struktura projektu

```
/home/arcz/uni/imsu/project/
├── backend/
│   ├── src/
│   │   ├── controllers/          # Logika biznesowa
│   │   │   ├── authController.ts
│   │   │   ├── surveyController.ts
│   │   │   └── varkController.ts
│   │   ├── routes/               # Endpointy API
│   │   │   ├── auth.ts
│   │   │   └── survey.ts
│   │   ├── types/                # TypeScript deklaracje
│   │   │   ├── express-session.d.ts
│   │   │   └── survey.ts
│   │   ├── db.ts                 # Pool PostgreSQL
│   │   └── server.ts             # Express app
│   ├── .env
│   ├── package.json
│   └── tsconfig.json
│
├── src/
│   ├── api/                      # API client (axios)
│   ├── components/               # React komponenty
│   │   ├── Header.tsx
│   │   ├── LoginComponent.tsx
│   │   └── LoginGreeter.tsx
│   ├── pages/                    # Strony aplikacji
│   │   ├── LandingPage.tsx
│   │   ├── LoginPage.tsx
│   │   ├── SurveyPage.tsx
│   │   └── DashboardPage.tsx
│   ├── styles/                   # CSS + Catppuccin Mocha
│   ├── types/                    # TypeScript typy
│   ├── App.tsx                   # Routing (React Router)
│   └── main.tsx                  # Entry point
│
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

---

## Użytkowanie aplikacji

### 1. Rejestracja
- Kliknij **"Create an account"** na stronie logowania
- Wypełnij: Full Name, Username, Email, Password (min. 6 znaków)
- Kliknij **"Create an account"**

### 2. Logowanie
- Wpisz username lub email
- Wpisz hasło
- Kliknij **"Sign In"**

### 3. Ankieta VARK
- Po zalogowaniu zostaniesz przekierowany do ankiety (jeśli jeszcze jej nie wypełniłeś)
- Wybierz odpowiedź dla każdego z 16 pytań
- Kliknij **"Dalej"** aby przejść do następnego pytania
- Na ostatnim pytaniu kliknij **"Wyślij"** aby zakończyć

### 4. Dashboard
- Po wysłaniu ankiety zostaniesz przekierowany na dashboard
- Tutaj możesz zobaczyć swój wynik VARK i statystyki

### 5. Wylogowanie
- Kliknij ikonę **logout** (wyloguj) w nagłówku
- Zostaniesz przekierowany na stronę logowania

---

## Główne funkcjonalności

✅ **Autentykacja użytkowników**
- Rejestracja z walidacją
- Logowanie przez username lub email
- Sesja server-side (express-session)
- JWT token (przechowywany w localStorage)
- Wylogowanie z czyszczeniem sesji

✅ **Ankieta VARK**
- 16 pytań interaktywnych
- Responsywny design (4 odpowiedzi w rzędzie na dużych ekranach)
- Możliwość cofnięcia się do poprzednich pytań
- Catppuccin Mocha dark theme
- Progress bar pokazujący postęp

✅ **Obliczanie wyniku VARK**
- Automatyczne zliczanie odpowiedzi per typ (Visual, Auditory, Reading, Kinesthetic)
- Zapisywanie wyników w bazie (`vark_scores` JSONB + `preferred_vark`)
- Obsługa remisów (zapisanie wielu zwycięzców)

✅ **Dashboard**
- Wyświetlanie preferowanego stylu uczenia
- Wyświetlanie pełnych wyników VARK

---

## API Endpointy

### Autentykacja
- `POST /api/auth/register` — rejestracja
- `POST /api/auth/login` — logowanie
- `GET /api/auth/me` — sprawdzenie sesji
- `POST /api/auth/logout` — wylogowanie

### Ankieta
- `GET /api/survey/questions` — pobierz pytania
- `POST /api/survey/submit` — wyślij odpowiedzi i oblicz VARK

---

## Troubleshooting

### Błąd: "Cannot find module 'pg'"
```bash
cd backend && npm install pg
```

### Błąd: "Connect ECONNREFUSED" (baza danych)
- Upewnij się, że PostgreSQL jest uruchomiony
- Sprawdź credentials w `backend/.env`
- Spróbuj połączyć się ręcznie: `psql -U multilearn_user -d multilearn`

### Błąd: "Port 5000 is already in use"
- Zmień port w `backend/.env` lub zamknij inną aplikację
- Alternatywnie: `lsof -i :5000` i `kill -9 <PID>`

### Frontend nie widzi backendu
- Upewnij się, że backend działa na `http://localhost:5000`
- Sprawdź `src/api/api.ts` — `baseURL` powinny być poprawne
- Sprawdź konfigurację CORS w `backend/src/server.ts`

---

## Rozwój

### Uruchom testy (jeśli dodane)
```bash
npm test
```

### Build produkcyjny frontendu
```bash
npm run build
```

### Uruchom TypeScript sprawdzenie
```bash
npm run type-check
```

