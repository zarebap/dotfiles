import { Request, Response } from 'express';
import pool from '../db';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { z } from 'zod';
dotenv.config();

const loginSchema = z.object({
  identifier: z.string().min(1).max(254), // can be email or username
  // allow shorter passwords for compatibility with existing users
  password: z.string().min(1).max(128),
});

export const register = async (req: Request, res: Response) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Brakuje danych wymaganych do rejestracji' });
  }

  if (typeof password === 'string' && password.length < 6) {
    return res.status(400).json({ error: 'Hasło musi mieć przynajmniej 6 znaków' });
  }

  try {
    const existingUser = await pool.query(
      'SELECT id FROM users WHERE email = $1 OR username = $2',
      [email, username]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({ error: 'Użytkownik o takim emailu lub username już istnieje' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (username, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, username, email, created_at`,
      [username, email, hashedPassword]
    );

    res.status(201).json({ user: result.rows[0] });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Błąd serwera' });
  }
};


export const login = async (req: Request, res: Response) => {
  // Accept `identifier` or `email` or `username` from the client
  const identifier = req.body?.identifier ?? req.body?.email ?? req.body?.username;
  const password = req.body?.password;

  if (typeof identifier !== 'string' || typeof password !== 'string') {
    const parsed = loginSchema.safeParse(req.body);
    console.error('Login validation failed', { body: req.body, issues: parsed.success ? [] : parsed.error.issues });
    return res.status(400).json({ error: 'Invalid input', details: parsed.success ? null : parsed.error.issues, body: req.body });
  }

  try {
    const result = await pool.query(
      'SELECT id, username, email, password_hash, has_completed_survey FROM users WHERE email = $1 OR username = $1',
      [identifier]
    );

    if (result.rows.length === 0)
      return res.status(401).json({ error: 'Invalid credentials' });

    const user = result.rows[0];

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    // create a JWT token to return to the frontend (optional — app uses sessions)
    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email },
      process.env.JWT_SECRET || 'jwtsecret',
      { expiresIn: '1h' }
    );

    // Also create a server-side session so `/auth/me` works for cookie-based flows
    req.session.regenerate((err) => {
      if (err) {
        console.error('session regenerate error', err);
        return res.status(500).json({ error: 'Server error' });
      }

      req.session.user = {
        id: user.id,
        username: user.username,
        email: user.email,
        hasCompletedSurvey: user.has_completed_survey
      };

      req.session.save((err2) => {
        if (err2) return res.status(500).json({ error: 'Session save failed' });

        return res.json({
          message: 'Logged in',
          token,
          user: req.session.user
        });
      });
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
};

export const completeSurvey = async (req: Request, res: Response) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });

  try {
    await pool.query(
      'UPDATE users SET has_completed_survey = TRUE WHERE id = $1',
      [req.session.user.id]
    );

    req.session.user.hasCompletedSurvey = true;
    req.session.save(err => {
      if (err) return res.status(500).json({ error: 'Session save failed' });
      res.json({ message: 'Survey completed' });
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

export const me = async (req: Request, res: Response) => {
  if (req.session && req.session.user) {
    return res.json({ user: req.session.user });
  }
  return res.status(401).json({ error: 'Not authenticated' });
};

export const logout = async (req: Request, res: Response) => {
  return new Promise<void>((resolve) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Session destroy error', err);
        res.status(500).json({ error: 'Failed to logout' });
        resolve();
        return;
      }
      res.clearCookie('connect.sid');
      res.json({ message: 'Logged out' });
      resolve();
    });
  });
};

