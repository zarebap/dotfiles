import { Request, Response } from 'express';
import pool from '../db';

export const createCourse = async (req: Request, res: Response) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });

  const { title, methods, lessons } = req.body as { title: string; methods: string[]; lessons: any[] };

  if (!title || !Array.isArray(lessons)) return res.status(400).json({ error: 'Invalid payload' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const courseRes = await client.query(
      `INSERT INTO courses (title, methods, created_by) VALUES ($1, $2, $3) RETURNING id, title, methods, created_at`,
      [title, methods || [], req.session.user.id]
    );

    const courseId = courseRes.rows[0].id;

    for (let i = 0; i < lessons.length; i++) {
      const l = lessons[i];
      const lessonType = l.lesson_type || 'lesson';
      const lessonRes = await client.query(
        `INSERT INTO lessons (course_id, position, title, content, lesson_type) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
        [courseId, i + 1, l.title || null, l.content || null, lessonType]
      );

      const lessonId = lessonRes.rows[0].id;

      if (lessonType === 'test' && Array.isArray(l.questions)) {
        for (const q of l.questions) {
          await client.query(
            `INSERT INTO test_questions (lesson_id, question, options, correct_index) VALUES ($1, $2, $3, $4)`,
            [lessonId, q.question || '', q.options || [], Number(q.correct_index) ?? 0]
          );
        }
      }

      if (Array.isArray(l.attachments)) {
        for (const a of l.attachments) {
          await client.query(
            `INSERT INTO attachments (lesson_id, type, url, filename) VALUES ($1, $2, $3, $4)`,
            [lessonId, a.type || 'link', a.url || null, a.filename || null]
          );
        }
      }
    }

    await client.query('COMMIT');

    res.status(201).json({ message: 'Course created', courseId });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
};

export const uploadFiles = async (req: Request, res: Response) => {
  // multer already saved files to disk
  // return array of { url, filename }
  const files = (req.files as Express.Multer.File[]) || [];

  const baseUrl = `${req.protocol}://${req.get('host')}/uploads`;

  const uploaded = files.map(f => ({ url: `${baseUrl}/${encodeURIComponent(f.filename)}`, filename: f.originalname }));

  res.json({ files: uploaded });
};

export const getCourse = async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  try {
    const courseRes = await pool.query('SELECT id, title, methods, created_by, created_at FROM courses WHERE id = $1', [id]);
    if (courseRes.rows.length === 0) return res.status(404).json({ error: 'Not found' });

    const lessonsRes = await pool.query('SELECT id, position, title, content, lesson_type FROM lessons WHERE course_id = $1 ORDER BY position', [id]);

    const lessons = [];
    for (const row of lessonsRes.rows) {
      const attachRes = await pool.query('SELECT id, type, url, filename FROM attachments WHERE lesson_id = $1', [row.id]);
      let questions: any[] = [];
      let lessonType = row.lesson_type || 'lesson';

      if (lessonType === 'test') {
        const qres = await pool.query('SELECT id, question, options, correct_index FROM test_questions WHERE lesson_id = $1 ORDER BY id ASC', [row.id]);
        questions = qres.rows;
      } else {
        // if older lessons were created before lesson_type existed, detect tests by presence of questions
        const qres = await pool.query('SELECT id, question, options, correct_index FROM test_questions WHERE lesson_id = $1 ORDER BY id ASC', [row.id]);
        if (qres.rows.length > 0) {
          questions = qres.rows;
          lessonType = 'test';
        }
      }

      lessons.push({ ...row, lesson_type: lessonType, attachments: attachRes.rows, questions });
    }

    res.json({ course: courseRes.rows[0], lessons });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

export const listCourses = async (req: Request, res: Response) => {
  try {
    console.log('listCourses called, user_id:', req.session.user?.id);
    let coursesResult;
    let userStyle = null;
    
    // If user is authenticated, filter by their VARK preference
    if (req.session.user) {
      const varkResult = await pool.query(
        'SELECT visual, auditory, reading, kinesthetic FROM survey_responses WHERE user_id = $1 ORDER BY id DESC LIMIT 1',
        [req.session.user.id]
      );

      if (varkResult.rows.length > 0) {
        const scores = varkResult.rows[0];
        console.log('User VARK scores:', scores);
        
        // Find dominant learning style
        const max = Math.max(scores.visual, scores.auditory, scores.reading, scores.kinesthetic);
        if (scores.visual === max) userStyle = 'visual';
        else if (scores.auditory === max) userStyle = 'auditory';
        else if (scores.reading === max) userStyle = 'reading';
        else if (scores.kinesthetic === max) userStyle = 'kinesthetic';

        console.log('Dominant learning style:', userStyle);

        // Get courses that include the user's dominant learning style or 'mixed'
        coursesResult = await pool.query(
          `SELECT id, title, methods, created_by, created_at 
           FROM courses 
           WHERE $1 = ANY(methods) OR 'mixed' = ANY(methods)
           ORDER BY created_at DESC`,
          [userStyle]
        );
        
        console.log(`Found ${coursesResult.rows.length} courses for ${userStyle} learners`);
        coursesResult.rows.forEach(course => {
          console.log(`  - ${course.title}: ${course.methods.join(', ')}`);
        });
      } else {
        console.log('No survey completed, showing all courses');
        // No survey completed, show all courses
        coursesResult = await pool.query('SELECT id, title, methods, created_by, created_at FROM courses ORDER BY created_at DESC');
      }
    } else {
      // Not authenticated, show all courses
      coursesResult = await pool.query('SELECT id, title, methods, created_by, created_at FROM courses ORDER BY created_at DESC');
    }

    res.json({ courses: coursesResult.rows, userStyle });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

export const getUserVarkStyle = async (req: Request, res: Response) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });

  try {
    const result = await pool.query(
      'SELECT visual, auditory, reading, kinesthetic FROM survey_responses WHERE user_id = $1 ORDER BY id DESC LIMIT 1',
      [req.session.user.id]
    );

    if (result.rows.length === 0) {
      return res.json({ hasCompleted: false });
    }

    const scores = result.rows[0];
    const max = Math.max(scores.visual, scores.auditory, scores.reading, scores.kinesthetic);
    let dominantStyle = '';
    if (scores.visual === max) dominantStyle = 'visual';
    else if (scores.auditory === max) dominantStyle = 'auditory';
    else if (scores.reading === max) dominantStyle = 'reading';
    else if (scores.kinesthetic === max) dominantStyle = 'kinesthetic';

    res.json({ hasCompleted: true, dominantStyle, scores });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

export const getUserProgress = async (req: Request, res: Response) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });

  try {
    const result = await pool.query(
      `SELECT up.*, c.title, c.methods, 
        (SELECT COUNT(*) FROM lessons WHERE course_id = up.course_id) as total_lessons
       FROM user_progress up
       JOIN courses c ON c.id = up.course_id
       WHERE up.user_id = $1
       ORDER BY up.last_accessed DESC`,
      [req.session.user.id]
    );
    res.json({ progress: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

export const updateProgress = async (req: Request, res: Response) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });

  const { courseId, lessonPosition, completed } = req.body;

  try {
    await pool.query(
      `INSERT INTO user_progress (user_id, course_id, current_lesson_position, completed, last_accessed)
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT (user_id, course_id)
       DO UPDATE SET current_lesson_position = $3, completed = $4, last_accessed = NOW()`,
      [req.session.user.id, courseId, lessonPosition, completed || false]
    );
    res.json({ message: 'Progress updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

