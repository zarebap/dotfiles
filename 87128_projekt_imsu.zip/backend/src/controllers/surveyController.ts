import { Request, Response } from 'express';
import pool from '../db';
import { SurveyInput } from '../types/survey';

export const submitSurvey = async (req: Request, res: Response) => {
  const { visual, auditory, reading, kinesthetic } = req.body as SurveyInput;

  console.log('Received survey data:', { user_id: req.session.user?.id, visual, auditory, reading, kinesthetic });

  if (!req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  try {
    // Use ON CONFLICT to handle duplicate submissions (update if exists)
    const result = await pool.query(
      `INSERT INTO survey_responses (user_id, visual, auditory, reading, kinesthetic)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (user_id) DO UPDATE SET
         visual = $2,
         auditory = $3,
         reading = $4,
         kinesthetic = $5
       RETURNING *`,
      [req.session.user.id, visual, auditory, reading, kinesthetic]
    );
    
    console.log('Survey saved:', result.rows[0]);

    await pool.query(
      'UPDATE users SET has_completed_survey = TRUE WHERE id = $1',
      [req.session.user.id]
    );

    console.log('User flag updated for user:', req.session.user.id);

    req.session.user.hasCompletedSurvey = true;
    req.session.save(err => {
      if (err) {
        console.error('Session save failed:', err);
        return res.status(500).json({ error: 'Session save failed' });
      }
      console.log('Session saved successfully');
      res.json({ message: 'Survey submitted successfully' });
    });

  } catch (err) {
    console.error('Survey submission error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

