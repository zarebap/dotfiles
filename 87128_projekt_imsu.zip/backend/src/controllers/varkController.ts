import pool from '../db';

export async function computeAndSaveVarkForUser(userId: number) {
  // Aggregate counts per vark_type
  const res = await pool.query(
    `SELECT a.vark_type, COUNT(*) AS cnt
     FROM survey_results sr
     JOIN answers a ON sr.answer_id = a.id
     WHERE sr.user_id = $1
     GROUP BY a.vark_type`,
    [userId]
  );

  const counts: Record<string, number> = { visual: 0, auditory: 0, reading: 0, kinesthetic: 0 };
  for (const row of res.rows) {
    const key = String(row.vark_type).toLowerCase();
    if (Object.prototype.hasOwnProperty.call(counts, key)) {
      counts[key] = parseInt(String(row.cnt), 10);
    }
  }

  // Determine winners (allow ties)
  const max = Math.max(...Object.values(counts));
  const winners = Object.keys(counts).filter(k => counts[k] === max && max > 0);
  const preferred = winners.length > 0 ? winners.join(',') : '';

  // Save to users table
  await pool.query(
    `UPDATE users SET vark_scores = $1::jsonb, preferred_vark = $2, has_completed_survey = TRUE WHERE id = $3`,
    [counts, preferred, userId]
  );

  // Also save to survey_responses table for the filtering to work
  await pool.query(
    `INSERT INTO survey_responses (user_id, visual, auditory, reading, kinesthetic)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (user_id) DO UPDATE SET
       visual = $2,
       auditory = $3,
       reading = $4,
       kinesthetic = $5`,
    [userId, counts.visual, counts.auditory, counts.reading, counts.kinesthetic]
  );

  console.log(`VARK computed for user ${userId}:`, counts);

  return { counts, preferred };
}

export default computeAndSaveVarkForUser;
