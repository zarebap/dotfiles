import express, { Request } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { uploadFiles, createCourse, getCourse, listCourses, getUserProgress, updateProgress, getUserVarkStyle } from '../controllers/courseController';

const router = express.Router();

// Use backend/public/uploads as storage root
const uploadsDir = path.join(__dirname, '../public/uploads');

// Ensure uploads directory exists
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) {
    cb(null, uploadsDir as unknown as string);
  },
  filename: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) {
    // keep a unique filename
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, `${unique}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB per file
});

// upload files (multiple)
router.post('/upload', upload.array('files', 20), uploadFiles);

// create course (expects JSON body)
router.post('/courses', createCourse);

// list courses
router.get('/courses', listCourses);

// get course with lessons
router.get('/courses/:id', getCourse);

// user progress
router.get('/progress', getUserProgress);
router.post('/progress', updateProgress);

// get user's VARK style
router.get('/vark-style', getUserVarkStyle);

export default router;
