import express from 'express';
import pool from '../db';
import { Request, Response } from 'express';
import { computeAndSaveVarkForUser } from '../controllers/varkController';

const router = express.Router();

// GET /api/survey/questions
router.get('/questions', async (req: Request, res: Response) => {
  console.log('GET /questions hit');
  try {
    const questionsResult = await pool.query('SELECT id, text FROM questions ORDER BY id ASC');
    const answersResult = await pool.query('SELECT id, question_id, text, vark_type FROM answers');

    const data = questionsResult.rows.map(q => ({
      id: q.id,
      text: q.text,
      answers: answersResult.rows.filter(a => a.question_id === q.id),
    }));

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch survey questions' });
  }
});

router.post('/submit', async (req: Request, res: Response) => {
  try {
    const userId = req.session.user?.id;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const answers: { questionId: number; answerId: number }[] = req.body;

    // Use a transaction: remove any previous answers for this user, then insert new ones
    await pool.query('BEGIN');
    try {
      await pool.query('DELETE FROM survey_results WHERE user_id = $1', [userId]);

      const queryText = 'INSERT INTO survey_results (user_id, question_id, answer_id) VALUES ($1, $2, $3)';
      for (const ans of answers) {
        await pool.query(queryText, [userId, ans.questionId, ans.answerId]);
      }

      await pool.query(
        'UPDATE users SET has_completed_survey = TRUE WHERE id = $1',
        [userId]
      );

      await pool.query('COMMIT');
    } catch (txErr) {
      await pool.query('ROLLBACK');
      throw txErr;
    }

    // compute VARK scores and save them
    try {
      console.log('Computing VARK for user', userId);
      const { counts, preferred } = await computeAndSaveVarkForUser(userId);
      console.log('VARK computed:', counts, 'preferred:', preferred);

      if (req.session.user) {
        req.session.user.hasCompletedSurvey = true;
        req.session.user.preferredVark = preferred;
        req.session.user.varkScores = counts;
        // save session so subsequent /auth/me sees updated values
        req.session.save(err => {
          if (err) console.error('session save error after vark compute', err);
          else console.log('Session updated after VARK compute');
        });
      }
    } catch (err) {
      console.error('Failed to compute/save VARK:', err);
      // don't block the response; survey answers are already stored
    }

    res.json({ message: 'Survey submitted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit survey' });
  }
});


export default router;

