import express from 'express';
import cors from 'cors';
import session from 'express-session';
import pgSession from 'connect-pg-simple';
import pool from './db';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = 5000;

// CORS needs to run before any middleware that could short-circuit the response
const corsOptions = { origin: 'http://localhost:5173', credentials: true };
app.use(cors(corsOptions));
// preflight is handled by cors middleware; no wildcard OPTIONS route to avoid path-to-regexp issues

app.use(helmet());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));
app.use(express.json());

const pgStore = pgSession(session);

app.use(
  session({
    store: new pgStore({
      pool: pool,
      tableName: 'session',
    }),
    secret: process.env.SESSION_SECRET || 'supersecret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24,
      secure: false,
      httpOnly: true,
    },
  })
);

import authRoutes from './routes/auth';
app.use('/api/auth', authRoutes);

import surveyRoutes from './routes/survey';
app.use('/api/survey', surveyRoutes);

import path from 'path';
import fs from 'fs';
import courseRoutes from './routes/course';

// ensure public uploads directory exists (backend/public/uploads)
const uploadsDir = path.join(__dirname, '../public/uploads');
try {
  fs.mkdirSync(uploadsDir, { recursive: true });
} catch (err) {
  console.error('Failed to create uploads dir', err);
}

// serve uploaded files at /uploads
app.use('/uploads', express.static(uploadsDir));

app.use('/api', courseRoutes);

// create tables if they don't exist yet and backfill schema gaps when running on an existing DB
const createTables = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS courses (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        methods TEXT[] DEFAULT ARRAY[]::TEXT[],
        created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS lessons (
        id SERIAL PRIMARY KEY,
        course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
        position INTEGER NOT NULL,
        title TEXT,
        content TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // ensure tests can be stored even if the lessons table was created before lesson_type existed
    await pool.query(`ALTER TABLE lessons ADD COLUMN IF NOT EXISTS lesson_type TEXT DEFAULT 'lesson';`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS test_questions (
        id SERIAL PRIMARY KEY,
        lesson_id INTEGER REFERENCES lessons(id) ON DELETE CASCADE,
        question TEXT NOT NULL,
        options TEXT[] NOT NULL,
        correct_index INTEGER NOT NULL
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS attachments (
        id SERIAL PRIMARY KEY,
        lesson_id INTEGER REFERENCES lessons(id) ON DELETE CASCADE,
        type TEXT,
        url TEXT,
        filename TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS user_progress (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
        current_lesson_position INTEGER DEFAULT 1,
        completed BOOLEAN DEFAULT FALSE,
        last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, course_id)
      );
    `);

    console.log('Ensured course tables exist');
  } catch (err) {
    console.error('Error creating tables', err);
  }
};

createTables();

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

