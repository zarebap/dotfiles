import 'express-session';

declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number;
      username: string;
      email: string;
      hasCompletedSurvey: boolean;
      // optional VARK fields we add at survey submit
      preferredVark?: string;
      varkScores?: Record<string, number>;
    };
  }
}
