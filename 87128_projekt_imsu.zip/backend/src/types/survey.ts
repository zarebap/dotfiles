export interface SurveyInput {
  visual: number;
  auditory: number;
  reading: number;
  kinesthetic: number;
}

