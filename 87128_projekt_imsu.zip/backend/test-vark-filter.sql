-- Test script to add VARK survey data and verify filtering
-- This script will help test the VARK-based course filtering

-- First, let's see what users exist
SELECT id, username, email, role FROM users;

-- Insert a test survey response for user 1 (if exists) with 'visual' as dominant style
-- visual=10, auditory=5, reading=3, kinesthetic=2
INSERT INTO survey_responses (user_id, visual, auditory, reading, kinesthetic)
VALUES (1, 10, 5, 3, 2)
ON CONFLICT DO NOTHING;

-- Check what courses we have
SELECT id, title, methods FROM courses;

-- Now verify the filter would work - courses that match 'visual' or 'mixed'
SELECT id, title, methods 
FROM courses 
WHERE 'visual' = ANY(methods) OR 'mixed' = ANY(methods);

-- Check the survey response was inserted
SELECT user_id, visual, auditory, reading, kinesthetic FROM survey_responses;
