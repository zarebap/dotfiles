import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import SurveyPage from './pages/SurveyPage';
import DashboardPage from './pages/DashboardPage';
import CreateCoursePage from './pages/CreateCoursePage';
import CourseListPage from './pages/CourseListPage';
import CoursePlayerPage from './pages/CoursePlayerPage';
import Header from './components/Header';

import './styles/CourseList.css';
import './styles/CoursePlayer.css';
import './styles/Header.css';
import './index.css';

export default function App() {
  const location = useLocation();
  const hideHeader = location.pathname === '/login';

  return (
    <div>
      {!hideHeader && <Header />}
      <main className={hideHeader ? '' : 'main-content'}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/survey" element={<SurveyPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/create-course" element={<CreateCoursePage />} />
          <Route path="/courses" element={<CourseListPage />} />
          <Route path="/courses/:id" element={<CoursePlayerPage />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
    </div>
  );
}
