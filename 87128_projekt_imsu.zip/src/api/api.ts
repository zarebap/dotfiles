import axios from 'axios';
import type { SurveyInput } from '../types/survey';

const API = axios.create({
  baseURL: 'http://localhost:5000/api',
  withCredentials: true,
});

export const loginUser = (data: { identifier: string; password: string }) =>
  API.post('/auth/login', data);

export const registerUser = (data: { username: string; email: string; password: string }) =>
  API.post('/auth/register', data);

export const submitSurvey = (data: any) =>
  API.post('/survey/submit', data);

export const getSurveyQuestions = () =>
  API.get('/survey/questions').then(res => res.data);

export const getCurrentUser = () =>
  API.get('/auth/me').then(res => res.data);

export const logoutUser = () =>
  API.post('/auth/logout');

export const uploadFiles = (formData: FormData) =>
  API.post('/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });

export const createCourse = (data: any) =>
  API.post('/courses', data);

export const getCourse = (id: number) =>
  API.get(`/courses/${id}`).then(res => res.data);

export const getCourses = () =>
  API.get('/courses').then(res => res.data);

export const getUserProgress = () =>
  API.get('/progress').then(res => res.data);

export const updateProgress = (data: { courseId: number; lessonPosition: number; completed?: boolean }) =>
  API.post('/progress', data);

