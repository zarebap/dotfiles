import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function CourseCard({ course }: { course: any }){
  const navigate = useNavigate();
  return (
    <div className="course-card">
      <div className="course-card-header">
        <h3>{course.title}</h3>
        <div className="course-methods">{(course.methods||[]).join(', ')}</div>
      </div>
      <div className="course-card-actions">
        <button className="btn-primary" onClick={()=>navigate(`/courses/${course.id}`)}>Open</button>
      </div>
    </div>
  );
}
