import '../styles/Header.css';
import { FaShoppingCart, FaHome, FaUser, FaImage, FaSignOutAlt } from "react-icons/fa";
import { IoSettingsSharp } from "react-icons/io5";
import { useNavigate } from 'react-router-dom';
import { logoutUser } from '../api/api';
import { Link } from 'react-router-dom';

export default function Header() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (err) {
      // ignore errors — still clear client state
    }
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <header className="header">
      <div className="brand">
        <h1><Link to="/" className="brand-link">MultiLearn</Link></h1>
      </div>
      <nav className="nav-links">
        <Link to="/dashboard" className="nav-item">Dashboard</Link>
        <Link to="/create-course" className="nav-item">Create Course</Link>
        <Link to="/courses" className="nav-item">Courses</Link>
      </nav>
      <div className="user-links">
        <button className="user-item" title="Profile"><FaUser size={18} /></button>
        <button className="user-item logout-button" onClick={handleLogout} title="Logout"><FaSignOutAlt size={16} /></button>
      </div>
    </header>
  );
};
