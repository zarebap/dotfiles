import { useState, useEffect } from 'react';
import '../styles/LoginComponent.css';
import { loginUser, registerUser, getCurrentUser } from '../api/api';
import { useNavigate } from 'react-router-dom';


interface FormFieldProps {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
}

const FormField: React.FC<FormFieldProps> = ({ label, type, value, onChange }) => {
  const [isFocused, setIsFocused] = useState(false);
  const formGroupClasses = `form-group ${value || isFocused ? 'active' : ''}`;
  const inputId = label.toLowerCase().replace(/\s/g, '-');

  return (
    <div className={formGroupClasses}>
      <label htmlFor={inputId} className="floating-label">{label}</label>
      <input
        id={inputId}
        type={type}
        className="login-input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
      />
    </div>
  );
};

const RegisterComponent: React.FC<{
  fullName: string;
  setFullName: (v: string) => void;
  username: string;
  setUsername: (v: string) => void;
  email: string;
  setEmail: (v: string) => void;
  password: string;
  setPassword: (v: string) => void;
  onRegister: () => void;
  registerError: string;
}> = ({ fullName, setFullName, username, setUsername, email, setEmail, password, setPassword, onRegister, registerError }) => {
  return (
    <div className="register-component">
      <p>Register to <span>MultiLearn</span></p>
      <div className="login-forms">
        <FormField label="Full Name" type="text" value={fullName} onChange={setFullName} />
        <FormField label="Username" type="text" value={username} onChange={setUsername} />
        <FormField label="Email address" type="email" value={email} onChange={setEmail} />
        <FormField label="Password" type="password" value={password} onChange={setPassword} />
      </div>
      {registerError && <p className="error-message">{registerError}</p>}
      <button type="submit" className="login-button" onClick={onRegister}>Create an account</button>
    </div>
  );
};

export default function LoginComponent() {
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [registerError, setRegisterError] = useState('');


  const [loginEmailOrUsername, setLoginEmailOrUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const [registerFullName, setRegisterFullName] = useState('');
  const [registerUsername, setRegisterUsername] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');

  const navigate = useNavigate();

  const toggleView = () => setIsRegistering(!isRegistering);

  useEffect(() => {
    const savedEmail = localStorage.getItem('loginEmail');

    if (savedEmail) setLoginEmailOrUsername(savedEmail);
  }, []);

  // On mount, check if user already has a session and redirect accordingly
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const resp = await getCurrentUser();
        const user = resp.user;
        if (!mounted) return;
        if (user) {
          // if user completed survey -> dashboard, otherwise survey
          if (user.hasCompletedSurvey) navigate('/dashboard');
          else navigate('/survey');
        }
      } catch (err) {
        // not authenticated or other error — stay on login
      }
    })();
    return () => { mounted = false; };
  }, [navigate]);

  const handleLogin = async () => {
  setLoginError('');
  try {
    const response = await loginUser({ identifier: loginEmailOrUsername, password: loginPassword });
    const data = response.data; // <- TUTAJ masz faktyczne dane z serwera

    console.log('Logged in user:', data);

    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    localStorage.setItem('loginEmail', loginEmailOrUsername);

    localStorage.removeItem('loginPassword');
    localStorage.removeItem('registerEmail');

    if (!data.user.hasCompletedSurvey) {
      navigate('/survey'); 
      return;
    }

    navigate('/dashboard'); 

  } catch (err: any) {
    const msg = err.response?.data?.error || 'Login failed. Please try again.';
    setLoginError(msg);
  }
};



  const handleRegister = async () => {
    setRegisterError('');
    try {
      const data = await registerUser({
        username: registerUsername,
        email: registerEmail,
        password: registerPassword
      });
      console.log('Registered user:', data);
      alert('Registration successful, please log in');
      setIsRegistering(false);
    } catch (err: any) {
      const msg = err.response?.data?.error || 'Registration failed.';
      setRegisterError(msg);
    }
  };

  if (isRegistering) {
    return (
      <div className="login-component">
        <div className="register-prompt" onClick={toggleView}>
          <p>Sign in</p>
        </div>
        <RegisterComponent
          fullName={registerFullName} setFullName={setRegisterFullName}
          username={registerUsername} setUsername={setRegisterUsername}
          email={registerEmail} setEmail={setRegisterEmail}
          password={registerPassword} setPassword={setRegisterPassword}
          onRegister={handleRegister}
          registerError={registerError}
        />
      </div>
    );
  }

  return (
    <div className="login-component">
      <div className="register-prompt" onClick={toggleView}>
        <p>Create an account</p>
      </div>
      <p>Sign in to <span>MultiLearn</span></p>

      <div className="login-forms">
        <FormField label="Username or email address" type="text" value={loginEmailOrUsername} onChange={setLoginEmailOrUsername} />
        <FormField label="Password" type="password" value={loginPassword} onChange={setLoginPassword} />
      </div>
      <span className="password-remind">Forgot password?</span>
      {loginError && <p className="error-message">{loginError}</p>}
      <button type="submit" className="login-button" onClick={handleLogin}>Sign In</button>
    </div>
  );
}

