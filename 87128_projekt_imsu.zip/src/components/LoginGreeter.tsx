import { useState } from 'react';
import '../styles/LoginGreeter.css';

export default function LoginGreeter() {
  const [isOpen, setIsOpen] = useState(false);

  const ToggleOpen = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="login-greeter">
      <h1>MultiLearn</h1>
      <p>Start learning more productive.</p>

      <div className="toggle-wrapper">
        <span
          className="check-more-toggle"
          onClick={ToggleOpen}
          aria-expanded={isOpen}
        >
          {isOpen ? 'View details about MultiLearn' : 'View details about MultiLearn'}
        </span>

        <div className={`more-content ${isOpen ? 'is-open' : ''}`}>
          <ul className="detailed-info-list">
            <li>Personalized Learning Paths.</li>
            <li>Multi-Modal Resources</li>
            <li>Smart Progress Tracking.</li>
            <li>Interactive, Engaging Experience.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
