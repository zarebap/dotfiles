import React, { useEffect, useState } from 'react';
import { getCourses } from '../api/api';
import { useNavigate } from 'react-router-dom';
import CourseCard from '../components/CourseCard';
import '../styles/CourseList.css';

export default function CourseListPage(){
  const [courses, setCourses] = useState<any[]>([]);
  const [userStyle, setUserStyle] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(()=>{
    (async ()=>{
      try{
        console.log('Fetching courses...');
        const res = await getCourses();
        console.log('Got response:', res);
        setCourses(res.courses || []);
        setUserStyle(res.userStyle);
      }catch(e){
        console.error('Error fetching courses:', e);
      }finally{setLoading(false)}
    })();
  }, []);

  if(loading) return <div className="course-list">Loading courses...</div>;

  return (
    <div className="course-list">
      <h1>Courses</h1>
      
      {!userStyle && (
        <div className="survey-prompt">
          <p>Complete the VARK survey to see courses personalized for your learning style!</p>
          <button onClick={() => navigate('/survey')} className="btn-primary">
            Take Survey
          </button>
        </div>
      )}
      
      {userStyle && (
        <div className="filter-badge">
          <p>Showing courses for <strong>{userStyle}</strong> learners</p>
        </div>
      )}
      
      {courses.length===0 && <p>No courses available.</p>}
      <div className="courses-grid">
        {courses.map(c=> (
          <CourseCard key={c.id} course={c} />
        ))}
      </div>
    </div>
  );
}
