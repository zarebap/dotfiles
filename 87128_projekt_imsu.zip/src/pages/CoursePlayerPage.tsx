import React, { useEffect, useState } from 'react';
import { getCourse, updateProgress } from '../api/api';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import '../styles/CoursePlayer.css';

export default function CoursePlayerPage(){
  const { id } = useParams();
  const [course, setCourse] = useState<any|null>(null);
  const [index, setIndex] = useState(0);
  const [searchParams] = useSearchParams();
  const [score, setScore] = useState<number | null>(null);
  const [showSurveyPrompt, setShowSurveyPrompt] = useState(false);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const navigate = useNavigate();

  useEffect(()=>{
    if(!id) return;
    (async ()=>{
      try{
        const res = await getCourse(Number(id));
        setCourse(res.course ? { ...res.course, lessons: res.lessons } : null);
      }catch(e){
        console.error(e);
      }
    })();
  },[id]);

  // Initialize index from query param `lesson` (1-based)
  useEffect(() => {
    const lessonParam = Number(searchParams.get('lesson'));
    if (!Number.isNaN(lessonParam) && lessonParam > 0) {
      setIndex(lessonParam - 1);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!course || !id) return;
    const lessonsLen = course.lessons?.length || 0;
    const lessonPosition = Math.min(Math.max(index, 0), Math.max(lessonsLen - 1, 0)) + 1;
    const completed = lessonPosition >= lessonsLen && lessonsLen > 0;
    updateProgress({ courseId: Number(id), lessonPosition, completed }).catch(console.error);
  }, [index, course, id]);

  if(!course) return <div className="course-player">Loading course...</div>;

  const lessons = course.lessons || [];
  const clampedIndex = Math.min(Math.max(index, 0), Math.max(lessons.length - 1, 0));
  const lesson = lessons[clampedIndex];
  const isTest = (lesson?.lesson_type === 'test') || (lesson?.questions && lesson.questions.length > 0);

  const handleTestSubmit = () => {
    if (!lesson?.questions) return;
    let correct = 0;
    lesson.questions.forEach((q: any) => {
      const picked = answers[q.id];
      if (picked === q.correct_index) correct += 1;
    });
    const total = lesson.questions.length || 1;
    const pct = Math.round((correct / total) * 100);
    setScore(pct);
    if (pct < 51) setShowSurveyPrompt(true);
  };

  return (
    <div className="course-player">
      <button className="btn-secondary" onClick={()=>navigate('/courses')}>Back to courses</button>
      <h1>{course.title}</h1>
      <div style={{marginTop:12}}>
          <div style={{ marginBottom: 12, fontSize: '0.9rem', color: 'var(--color-muted)' }}>
          Lesson {clampedIndex + 1} of {lessons.length}
        </div>
        <h3>{lesson?.title || `Lesson ${clampedIndex+1}`}</h3>

        {!isTest && (
          <>
            <div className="lesson-content">{lesson?.content}</div>
            {lesson?.attachments?.length > 0 && (
              <div className="attachments-list">
                <h4>Attachments</h4>
                <ul>
                  {lesson.attachments.map((a:any)=>(
                    <li key={a.id}><a href={a.url} target="_blank" rel="noreferrer">{a.filename || a.url}</a></li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}

        {isTest && (
          <div className="test-runner">
            {lesson.questions && lesson.questions.length > 0 ? lesson.questions.map((q:any, qi:number)=>(
              <div key={q.id} className="question-block">
                <div className="question-text">{qi+1}. {q.question}</div>
                <div className="answers-list">
                  {q.options.map((opt:string, oi:number)=>(
                    <label key={oi} className={`answer-row ${answers[q.id] === oi ? 'selected' : ''}`}>
                      <input
                        type="radio"
                        name={`q-${q.id}`}
                        checked={answers[q.id] === oi}
                        onChange={()=>setAnswers(prev=>({ ...prev, [q.id]: oi }))}
                      />
                      <span>{opt}</span>
                    </label>
                  ))}
                </div>
              </div>
            )) : <p className="muted">No questions defined for this test.</p>}
            <div className="player-controls">
              <button className="btn-primary" onClick={handleTestSubmit}>Submit test</button>
              {score !== null && <span className="test-score">Score: {score}%</span>}
            </div>
          </div>
        )}

        <div className="player-controls">
          <button className="btn-secondary" onClick={()=>setIndex(i=>Math.max(0,i-1))} disabled={clampedIndex===0}>Previous</button>
          <button className="btn-primary" onClick={()=>setIndex(i=>Math.min(lessons.length-1,i+1))} disabled={clampedIndex>=lessons.length-1}>Next</button>
        </div>
      </div>
      {showSurveyPrompt && (
        <div className="modal-overlay">
          <div className="modal-card">
            <h3>Need help?</h3>
            <p>Your score is below 51%. Would you like to retake the VARK survey to adjust your learning style?</p>
            <div className="modal-actions">
              <button className="btn-primary" onClick={()=>{ setShowSurveyPrompt(false); navigate('/survey'); }}>Retake survey</button>
              <button className="btn-secondary" onClick={()=>setShowSurveyPrompt(false)}>Maybe later</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
