import React, { useState } from 'react';
import { createCourse, uploadFiles } from '../api/api';
import '../styles/CreateCourse.css';

type Lesson = {
  title?: string;
  content: string;
  fileInputs?: File[];
  links?: string[];
  lesson_type?: 'lesson' | 'test';
  questions?: TestQuestion[];
};

type TestQuestion = { question: string; options: string[]; correct_index: number };

export default function CreateCoursePage() {
  const [title, setTitle] = useState('');
  const [methods, setMethods] = useState<string[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([{ content: '', lesson_type: 'lesson', questions: [] }]);
  const [saving, setSaving] = useState(false);

  const toggleMethod = (m: string) => {
    setMethods(prev => prev.includes(m) ? prev.filter(x => x !== m) : [...prev, m]);
  };

  const updateLesson = (index: number, patch: Partial<Lesson>) => {
    setLessons(prev => prev.map((l, i) => i === index ? { ...l, ...patch } : l));
  };

  const addLesson = () => setLessons(prev => [...prev, { content: '' }]);
  const removeLesson = (i: number) => setLessons(prev => prev.filter((_, idx) => idx !== i));

  const handleFileChange = (index: number, files: FileList | null) => {
    if (!files) return;
    updateLesson(index, { fileInputs: Array.from(files) });
  };

  const addLink = (index: number, link: string) => {
    if (!link) return;
    setLessons(prev => prev.map((l, i) => i === index ? { ...l, links: [...(l.links || []), link] } : l));
  };

  const removeLink = (index: number, linkIdx: number) => {
    setLessons(prev => prev.map((l, i) => i === index ? { ...l, links: l.links?.filter((_, k) => k !== linkIdx) } : l));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      // upload files per lesson
      const lessonsPayload = [] as any[];

      for (const l of lessons) {
        const attachments: any[] = [];

        if (l.fileInputs && l.fileInputs.length > 0) {
          const fd = new FormData();
          for (const f of l.fileInputs) fd.append('files', f);
          const res = await uploadFiles(fd);
          const files = res.data.files as Array<{ url: string; filename: string }>;
          for (const f of files) attachments.push({ type: 'file', url: f.url, filename: f.filename });
        }

        if (l.links && l.links.length > 0) {
          for (const link of l.links) attachments.push({ type: 'link', url: link });
        }

        lessonsPayload.push({ title: l.title, content: l.content, attachments, lesson_type: l.lesson_type || 'lesson', questions: l.questions });
      }

      await createCourse({ title, methods, lessons: lessonsPayload });
      alert('Course created');
      // reset form
      setTitle(''); setMethods([]); setLessons([{ content: '' }]);
    } catch (err) {
      console.error(err);
      alert('Failed to create course');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container-card">
      <h1>Create Course</h1>
      <form onSubmit={handleSubmit} className="create-course-form">
        <div className="form-row">
          <label>Course title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} required className="input-wide" />
        </div>

        <div className="form-row">
          <label>Teaching methods (choose any)</label>
          <div className="methods-row">
            {['visual','auditory','reading','kinesthetic','mixed'].map(m => (
              <label key={m} className={`method-pill ${methods.includes(m) ? 'active' : ''}`}>
                <input type="checkbox" checked={methods.includes(m)} onChange={() => toggleMethod(m)} />
                <span>{m}</span>
              </label>
            ))}
          </div>
        </div>

        <hr />

        <h3>Lessons</h3>
        {lessons.map((l, idx) => (
          <div key={idx} className="lesson-card">
            <div className="form-row inline-row">
              <label>Lesson type</label>
              <div className="pill-switch">
                {['lesson','test'].map(t => (
                  <button
                    type="button"
                    key={t}
                    className={`pill ${ (l.lesson_type||'lesson') === t ? 'active' : ''}`}
                    onClick={() => updateLesson(idx, { lesson_type: t as any })}
                  >
                    {t === 'lesson' ? 'Lesson' : 'Test'}
                  </button>
                ))}
              </div>
            </div>
            <div className="form-row">
              <label>Optional lesson title</label>
              <input value={l.title || ''} onChange={e => updateLesson(idx, { title: e.target.value })} className="input-medium" />
            </div>
            {(l.lesson_type || 'lesson') === 'lesson' && (
              <div className="form-row">
                <label>Lesson content</label>
                <textarea value={l.content} onChange={e => updateLesson(idx, { content: e.target.value })} rows={6} className="textarea-wide" required />
              </div>
            )}
            {(l.lesson_type || 'lesson') === 'test' && (
              <TestBuilder lesson={l} onChange={(val)=>updateLesson(idx, { questions: val })} />
            )}
            <div className="form-row">
              <label>Files (you can add multiple)</label>
              <div className="file-input-row">
                <input id={`file-input-${idx}`} type="file" multiple onChange={e => handleFileChange(idx, e.target.files)} className="file-hidden" />
                <label htmlFor={`file-input-${idx}`} className="file-btn">Choose files</label>
                <span className="file-hint">Supported: any, max 20MB per file</span>
              </div>
            </div>
            <div className="form-row">
              <label>Links</label>
              <LinkInputs lesson={l} index={idx} addLink={(link)=>addLink(idx, link)} removeLink={(linkIdx)=>removeLink(idx, linkIdx)} />
            </div>
            <div className="form-row form-actions">
              <button type="button" onClick={() => removeLesson(idx)} disabled={lessons.length<=1} className="btn-ghost">Remove lesson</button>
            </div>
          </div>
        ))}

        <div className="form-row">
          <button type="button" onClick={addLesson} className="btn-primary">Add lesson</button>
        </div>

        <div className="form-row">
          <button type="submit" disabled={saving} className="btn-primary">{saving ? 'Saving...' : 'Save course'}</button>
        </div>
      </form>
    </div>
  );
}

function LinkInputs({ lesson, index, addLink, removeLink }: { lesson: Lesson; index: number; addLink: (l: string)=>void; removeLink: (i:number)=>void }){
  const [value, setValue] = useState('');
  return (
    <div>
      <div className="link-input-row">
        <input placeholder="https://..." value={value} onChange={e=>setValue(e.target.value)} className="input-wide" />
        <button type="button" onClick={() => { addLink(value); setValue(''); }} className="btn-primary">Add link</button>
      </div>
      <ul>
        {(lesson.links||[]).map((l, i)=> (
          <li key={i}>{l} <button type="button" onClick={()=>removeLink(i)} className="btn-ghost">remove</button></li>
        ))}
      </ul>
    </div>
  );
}

function TestBuilder({ lesson, onChange }: { lesson: Lesson; onChange: (q: TestQuestion[])=>void }) {
  const questions = lesson.questions || [];
  const updateQuestion = (idx: number, patch: Partial<TestQuestion>) => {
    onChange(questions.map((q, i) => i === idx ? { ...q, ...patch } : q));
  };
  const updateOption = (qIdx: number, optIdx: number, value: string) => {
    const qs = questions.map((q, i) => {
      if (i !== qIdx) return q;
      const opts = [...(q.options || [])];
      opts[optIdx] = value;
      return { ...q, options: opts };
    });
    onChange(qs);
  };
  const addQuestion = () => {
    onChange([...(questions || []), { question: '', options: ['', '', '', ''], correct_index: 0 }]);
  };
  const removeQuestion = (idx: number) => {
    onChange(questions.filter((_, i) => i !== idx));
  };
  return (
    <div className="test-builder">
      <div className="form-row">
        <label>Test questions</label>
        <button type="button" className="btn-primary" onClick={addQuestion}>Add question</button>
      </div>
      {questions.length === 0 && <p className="muted">No questions yet.</p>}
      {questions.map((q, qi) => (
        <div key={qi} className="question-card">
          <div className="form-row">
            <label>Question</label>
            <input className="input-wide" value={q.question} onChange={e=>updateQuestion(qi, { question: e.target.value })} />
          </div>
          <div className="options-grid">
            {(q.options || []).map((opt, oi) => (
              <label key={oi} className="option-row">
                <input
                  type="radio"
                  name={`correct-${qi}`}
                  checked={q.correct_index === oi}
                  onChange={()=>updateQuestion(qi, { correct_index: oi })}
                />
                <input
                  className="input-wide"
                  value={opt}
                  onChange={e=>updateOption(qi, oi, e.target.value)}
                  placeholder={`Answer ${oi+1}`}
                />
              </label>
            ))}
          </div>
          <div className="form-row form-actions">
            <button type="button" className="btn-ghost" onClick={()=>removeQuestion(qi)}>Remove question</button>
          </div>
        </div>
      ))}
    </div>
  );
}
