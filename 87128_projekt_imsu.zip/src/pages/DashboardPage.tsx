import React, { useEffect, useState } from 'react';
import { getUserProgress } from '../api/api';
import { useNavigate } from 'react-router-dom';

interface Progress {
  id: number;
  course_id: number;
  current_lesson_position: number;
  completed: boolean;
  title: string;
  methods: string[];
  total_lessons: number;
  last_accessed: string;
}

export default function DashboardPage() {
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const res = await getUserProgress();
        setProgress(res.progress || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="container-card"><p>Loading...</p></div>;

  return (
    <div>
      <h1>Dashboard</h1>
      <p style={{ marginBottom: 16, color: 'var(--color-muted)' }}>Your courses in progress</p>

      <div style={{ marginBottom: 24, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <button className="btn-primary" onClick={() => navigate('/survey')} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          Retake Survey
        </button>
        <button className="btn-secondary" onClick={() => navigate('/courses')} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          Browse All Courses
        </button>
      </div>

      {progress.length === 0 && (
        <div className="container-card" style={{ textAlign: 'center', padding: 32 }}>
          <p>No courses started yet.</p>
          <button className="btn-primary" onClick={() => navigate('/courses')} style={{ marginTop: 12 }}>Browse Courses</button>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
        {progress.map((p) => (
          <div key={p.id} className="container-card" style={{ padding: 16 }}>
            <h3 style={{ margin: '0 0 8px 0' }}>{p.title}</h3>
            <div style={{ fontSize: '0.85rem', color: 'var(--color-muted)', marginBottom: 8 }}>
              {p.methods.join(', ')}
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: '0.9rem', marginBottom: 4 }}>
                Lesson {p.current_lesson_position} of {p.total_lessons}
              </div>
              <div style={{ height: 6, background: 'var(--color-surface-light)', borderRadius: 999, overflow: 'hidden' }}>
                <div
                  style={{
                    width: `${(p.current_lesson_position / p.total_lessons) * 100}%`,
                    height: '100%',
                    background: 'var(--color-accent)',
                    transition: 'width 0.3s ease'
                  }}
                />
              </div>
            </div>
            {p.completed ? (
              <div style={{ color: 'var(--color-accent)', fontSize: '0.9rem' }}>✓ Completed</div>
            ) : (
              <button
                className="btn-primary"
                onClick={() => {
                  const lessonPos = Math.max(1, p.current_lesson_position || 1);
                  navigate(`/courses/${p.course_id}?lesson=${lessonPos}`);
                }}
              >
                Continue
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
