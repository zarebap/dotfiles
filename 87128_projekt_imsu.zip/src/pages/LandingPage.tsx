export default function LandingPage() {
  return (
    <div>
      <div style={{padding:24}}>
        <h2>Welcome to MultiLearn</h2>
        <p>A platform for creating and browsing courses tailored to learning styles.</p>
      </div>
    </div>
  );
}
