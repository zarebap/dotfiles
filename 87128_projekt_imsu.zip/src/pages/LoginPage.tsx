import LoginGreeter from '../components/LoginGreeter';
import LoginComponent from '../components/LoginComponent';
import '../styles/LoginPage.css';

export default function LoginPage() {
  return (
    <div className="login-page">
      <LoginGreeter />
      <LoginComponent />
    </div>
  );
}
