import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { submitSurvey, getSurveyQuestions } from '../api/api';
import type { SurveyInput } from '../types/survey';
import '../styles/SurveyPage.css';

interface Answer {
  id: number;
  text: string;
  vark_type: keyof SurveyInput;
}

interface Question {
  id: number;
  text: string;
  answers: Answer[];
}

export default function SurveyPage() {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  // store selected answer per question id
  const [answersMap, setAnswersMap] = useState<Record<number, number>>({});
  const [selectedAnswerId, setSelectedAnswerId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // pobranie pytań z backendu
  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const data = await getSurveyQuestions(); // zakładam GET /api/survey
        setQuestions(data);
        setLoading(false);
      } catch (err: any) {
        setError(err.response?.data?.error || 'Failed to load survey questions');
        setLoading(false);
      }
    };
    fetchQuestions();
  }, []);

  // when questions load or currentIndex changes, restore selected if previously answered
  useEffect(() => {
    if (!questions || questions.length === 0) return;
    const q = questions[currentIndex];
    if (!q) return;
    const prev = answersMap[q.id];
    setSelectedAnswerId(prev ?? null);
  }, [currentIndex, questions]);

  const handleNext = () => {
    if (selectedAnswerId === null) {
      setError('Wybierz odpowiedź, aby przejść dalej');
      return;
    }
    setError('');
    // save answer
    setAnswersMap(prev => ({ ...prev, [questions[currentIndex].id]: selectedAnswerId }));
    setCurrentIndex(prev => prev + 1);
  };

  const handleSubmit = async () => {
    // ensure current question is saved
    if (selectedAnswerId === null) {
      setError('Please select an answer before submitting');
      return;
    }
    const finalMap = { ...answersMap, [questions[currentIndex].id]: selectedAnswerId };
    try {
      // Send question/answer pairs (not VARK scores - backend will calculate them)
      const surveyAnswers = questions.map(q => ({ questionId: q.id, answerId: finalMap[q.id] }));
      console.log('Submitting survey answers:', surveyAnswers);
      await submitSurvey(surveyAnswers);
      // Redirect to courses page to see personalized results
      navigate('/courses');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to submit survey');
    }
  };

  if (loading) return <p>Loading...</p>;
  if (questions.length === 0) return <p>No survey questions available</p>;

  const currentQuestion = questions[currentIndex];

  return (
    <div className="survey-page">
      <main className="survey-container">
        <header className="survey-header">
          <h1>VARK — Learning Style Survey</h1>
          <p className="survey-sub">A short survey will help you match the best materials to your learning style.</p>
          <div className="progress">
            <div className="progress-bar" style={{ width: `${((currentIndex) / questions.length) * 100}%` }} />
            <span className="progress-text">Pytanie {currentIndex + 1} / {questions.length}</span>
          </div>
        </header>

        <section className="question-card">
          <h2 className="question-text">{currentQuestion.text}</h2>

          <div className="answers-grid">
            {currentQuestion.answers.map((a) => (
              <label key={a.id} className={`answer-card ${selectedAnswerId === a.id ? 'selected' : ''}`}>
                <input
                  type="radio"
                  name={`question-${currentQuestion.id}`}
                  value={a.id}
                  checked={selectedAnswerId === a.id}
                  onChange={() => setSelectedAnswerId(a.id)}
                />
                <div className="answer-content">
                  <p className="answer-text">{a.text}</p>
                  <span className="answer-type">{a.vark_type}</span>
                </div>
              </label>
            ))}
          </div>

          {error && <p className="error-text">{error}</p>}

          <div className="actions">
            {currentIndex < questions.length - 1 ? (
              <button className="btn btn-primary" onClick={handleNext}>Next</button>
            ) : (
              <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>
            )}
            <button className="btn btn-ghost" onClick={() => navigate('/')}>Cancel</button>
          </div>
        </section>
      </main>
    </div>
  );
}

